
<!DOCTYPE html>
<html xmlns='http://www.w3.org/1999/xhtml' xmlns:b='http://www.google.com/2005/gml/b' xmlns:data='http://www.google.com/2005/gml/data' xmlns:expr='http://www.google.com/2005/gml/expr'>
<meta content='MUJERES SEXYS' property='og:type'/>
<meta content='CHICAS MALAS' property='og:title'/>
<meta content='SOLO MAYORES +22' property='og:description'/>
<meta content='https://i.imgur.com/Hro5aak.png' property='og:image'/>
<script>
<!--
document.write(unescape("%3Cscript%20id%3D%22_wau1ii%22%3Evar%20_wau%20%3D%20_wau%20%7C%7C%20%5B%5D%3B%20_wau.push%28%5B%22dynamic%22%2C%20%2247r3qnirtw%22%2C%20%221ii%22%2C%20%22c4302bffffff%22%2C%20%22small%22%5D%29%3B%3C/script%3E%3Cscript%20async%20src%3D%22//waust.at/d.js%22%3E%3C/script%3E%0A"));
//-->
</script>
<html lang="en">
  <head>
    <style type="text/css">
      .waubutton {
        display: inline-block;
        position: relative;
        background-color: rgb(0, 0, 0);
        color: rgb(255, 255, 255);
        text-decoration: none;
        text-transform: lowercase;
        letter-spacing: -2px;
        text-shadow: 0px 1px 0px rgba(0, 0, 0, 0.5);
        -ms-filter: "progid:DXImageTransform.Microsoft.dropshadow(OffX=0,OffY=1,Color=#ff123852,Positive=true)";
        zoom: 1;
        width: 50px;
        filter: progid: DXImageTransform.Microsoft.dropshadow(OffX=0, OffY=1, Color=#ff123852, Positive=true);
        -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.2);
        -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.2);
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.2);
        -ms-filter: "progid:DXImageTransform.Microsoft.dropshadow(OffX=0,OffY=2,Color=#33000000,Positive=true)";
        filter: progid: DXImageTransform.Microsoft.dropshadow(OffX=0, OffY=2, Color=#33000000, Positive=true);
      }
      .waubutton:hover {
        text-decoration: none !important;
        color: #eeeaee !important;
      }
      .waubutton p {
        position: relative !important;
        font-family: "Inconsolata", sans-serif;
        font-weight: 700 !important;
        line-height: inherit !important;
      }
      .waubutton span {
        position: absolute !important;
        left: 15px !important;
        width: 50px !important;
        font-size: 30px !important;
        -webkit-border-top-left-radius: 5px !important;
        -webkit-border-bottom-left-radius: 5px !important;
        -moz-border-radius-topleft: 5px !important;
        -moz-border-radius-bottomleft: 5px !important;
        border-top-left-radius: 5px !important;
        border-bottom-left-radius: 5px !important;
        text-decoration: none !important;
      }
      .waubutton img {
        margin-top: 3px !important;
        vertical-align: 0 !important;
        border: 0 !important;
        mix-blend-mode: overlay;
      }
      @-webkit-keyframes push {
        50% {
          -webkit-transform: scale(0.9);
          transform: scale(0.9);
        }
        100% {
          -webkit-transform: scale(1);
          transform: scale(1);
        }
      }
      @keyframes push {
        50% {
          -webkit-transform: scale(0.9);
          transform: scale(0.9);
        }
        100% {
          -webkit-transform: scale(1);
          transform: scale(1);
        }
      }
      .push {
        display: inline-block;
        -webkit-transform: translateZ(0);
        transform: translateZ(0);
        box-shadow: 0 0 1px rgba(0, 0, 0, 0);
      }
      .push:hover,
      .push:focus,
      .push:active {
        -webkit-animation-name: push;
        animation-name: push;
        -webkit-animation-duration: 0.2s;
        animation-duration: 0.2s;
        -webkit-animation-timing-function: linear;
        animation-timing-function: linear;
        -webkit-animation-iteration-count: 1;
        animation-iteration-count: 1;
      }
    </style>
  <link rel="me" href="https://www.blogger.com/profile/16520093022108791955" />
<link rel="me" href="https://draft.blogger.com/profile/05879422613630555088" />
<link rel="me" href="https://www.blogger.com/profile/16520093022108791955" />
<link rel="me" href="https://www.blogger.com/profile/17207620569950045352" />
<link rel="me" href="https://www.blogger.com/profile/13325523637040351255" />
<link rel="me" href="https://www.blogger.com/profile/16520093022108791955" />
<link rel="me" href="https://www.blogger.com/profile/15868542796637842310" />
<meta name='google-adsense-platform-account' content='ca-host-pub-1556223355139109'/>
<meta name='google-adsense-platform-domain' content='blogspot.com'/>
<link rel="me" href="https://www.blogger.com/profile/01532567688646983345" />
<meta name='google-adsense-platform-account' content='ca-host-pub-1556223355139109'/>
<meta name='google-adsense-platform-domain' content='blogspot.com'/>
<link rel="me" href="https://www.blogger.com/profile/06297096711526575067" />
<meta name='google-adsense-platform-account' content='ca-host-pub-1556223355139109'/>
<meta name='google-adsense-platform-domain' content='blogspot.com'/>
<link rel="me" href="https://www.blogger.com/profile/03596037215509698817" />
<meta name='google-adsense-platform-account' content='ca-host-pub-1556223355139109'/>
<meta name='google-adsense-platform-domain' content='blogspot.com'/>
<link rel="me" href="https://www.blogger.com/profile/12762595509917797825" />
<meta name='google-adsense-platform-account' content='ca-host-pub-1556223355139109'/>
<meta name='google-adsense-platform-domain' content='blogspot.com'/>
<link rel="me" href="https://www.blogger.com/profile/12762595509917797825" />
<meta name='google-adsense-platform-account' content='ca-host-pub-1556223355139109'/>
<meta name='google-adsense-platform-domain' content='blogspot.com'/>
<link rel="me" href="https://www.blogger.com/profile/12762595509917797825" />
<meta name='google-adsense-platform-account' content='ca-host-pub-1556223355139109'/>
<meta name='google-adsense-platform-domain' content='blogspot.com'/>
<link rel="me" href="https://www.blogger.com/profile/12762595509917797825" />
<meta name='google-adsense-platform-account' content='ca-host-pub-1556223355139109'/>
<meta name='google-adsense-platform-domain' content='blogspot.com'/>
<link rel="me" href="https://www.blogger.com/profile/12762595509917797825" />
<meta name='google-adsense-platform-account' content='ca-host-pub-1556223355139109'/>
<meta name='google-adsense-platform-domain' content='blogspot.com'/>
</head>
  <body>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no"
    />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link
      rel="shortcut icon"
      href="https://cdn.smrt-content.com/assets/1155/other/favicon.ico"
      type="image/x-icon"
    />
    <link
      rel="stylesheet"
      href="https://cdn.smrt-content.com/assets/1155/css/style.css"
    />
    <script src="https://cdn.smrt-content.com/assets/1155/js/jquery.js"></script>
    <script src="https://cdn.smrt-content.com/assets/1155/js/multilang.js"></script>
    <title>TIK TOK</title>
    <script type="text/javascript">
      $(document).ready(function () {
        $('.next').click(function(){
            $('#q00').hide();
            $('#q0').show();
        });
      });
    </script>
    <div class="layer"></div>
    <div id="container" align="left">
      <div id="q00" class="toggleDiv" style="display: block" align="center">
        <div class="mobile-center">
          <div class="videobgbox">
            <video class="video" loop="" autoplay="" muted="" playsinline="">
              <source
                src="https://sluttydates.com/landing/img/landing-28/4.mp4?55"
                type="video/mp4"
              />
            </video>
          </div>
          <div id="box" class="box-bg" align="center" style="margin-top: 0px">
            <div id="first-title" align="center">
              <h1 class="font-style title">?ADVERTENCIA!</h1>
            </div>
            <p class="text main-text">
              Vas a ver fotos con desnudos. Por favor, s? discreto.
            </p>
            <a class="show_hide" href="#" rel="#q0">
              <div class="wrap">
                <div class="btn">
                  <div class="btn-cap next">CONTINUAR</div>
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
      <div id="q0" class="toggleDiv" style="display: none" align="left">
        <div class="put-center">
          <div class="videobgbox2">
            <video class="video2" loop="" autoplay="" muted="" playsinline="">
              <source
                src="https://cdn.smrt-content.com/assets/1155/video/neon.mp4"
                type="video/mp4"
              />
            </video>
          </div>
          <div id="box">
            <div id="top" align="center">
              <span class="h1">
                <p class="font-style subtitle">
                  DEBES CUMPLIR LAS NORMAS DE ABAJO
                </p>
              </span>
            </div>
            <p class="item-1">
              ?? Si ves a alguien que conoces, NO lo publicites y no propagues
              rumores.
            </p>
            <p class="item-2">
              ?? Si practicas sexo con alguno de nuestros usuarios, es tu
              responsabilidad protegerte contra las enfermedades de transmisi?n
              sexual.
            </p>
            <p class="item-3">
              ?? Respeta los derechos sexuales de los dem?s usuarios. Nuestros
              usuarios son hombres y mujeres normales, no son estrellas del
              porno ni prostitutas.
            </p>
            <a
              href="https://smrtsecure-ad.com/smartlink/?a=144693&sm=11204&mt=26&s1=est"
            >
              <div class="wrap">
                <div class="btn-yes">
                  <div class="btn-cap btn-fin">ACEPTO</div>
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>